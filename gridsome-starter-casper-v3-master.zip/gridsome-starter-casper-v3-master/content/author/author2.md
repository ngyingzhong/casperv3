---
id: author2
name: Hans Wurst
bio: Quisque augue nibh etiam venenatis inceptos aliquet inceptos conubia, diam per mollis nibh scelerisque molestie
facebook: https://www.facebook.com
twitter: https://www.twitter.com
linkedin: https://www.linkedin.com
image: ./images/author2.png
---